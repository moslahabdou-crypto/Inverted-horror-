package com.reversehorror;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * The "K" control. Two ways to use it:
 *  - a "K" button in the top-left of the inventory screen and the pause menu (works on touch)
 *  - a key binding (K by default; change it in Options > Controls)
 */
@Mod.EventBusSubscriber(modid = ReverseHorror.MODID,
        bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    public static final KeyMapping TELEPORT_KEY = new KeyMapping(
            "key.reverse_horror.teleport_ai", InputConstants.KEY_K,
            "key.categories.reverse_horror");

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        while (TELEPORT_KEY.consumeClick()) {
            if (Minecraft.getInstance().player != null) {
                ModNetwork.CHANNEL.sendToServer(new TeleportToAIPacket());
            }
        }
    }

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (event.getScreen() instanceof InventoryScreen || event.getScreen() instanceof PauseScreen) {
            Button w = Button.builder(Component.literal("K"),
                            b -> ModNetwork.CHANNEL.sendToServer(new TeleportToAIPacket()))
                    .bounds(6, 6, 20, 20).build();
            event.addListener(w);
        }
    }
}
