package com.reversehorror;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/** Spawning, respawning, chunk keeping and the W teleport for the single AI player. */
public class AIPlayerManager {
    public static final double SPAWN_DISTANCE = 12.0D;
    public static final double TELEPORT_MIN_DISTANCE = 13.0D;
    public static final long RESPAWN_DELAY_TICKS = 100L;

    public static boolean isNight(Level level) {
        if (level.dimensionType().hasFixedTime()) return false;
        long t = level.getDayTime() % 24000L;
        return t >= 13000L && t < 23000L;
    }

    // ---- Server tick: spawn / respawn / lost-entity recovery ----------------
    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 40 != 0) return;
        ServerLevel level = server.overworld();
        AIPlayerData data = AIPlayerData.get(server);

        if (!data.spawned) {
            ServerPlayer p = null;
            for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
                if (sp.level() == level && !sp.isSpectator()) {
                    p = sp;
                    break;
                }
            }
            if (p == null) return;
            BlockPos pos = findSpawnAround(level, p.blockPosition(), SPAWN_DISTANCE);
            data.origin = pos;
            data.spawned = true;
            data.setDirty();
            spawn(level, data, Vec3.atBottomCenterOf(pos));
            return;
        }

        if (data.dead) {
            if (level.getGameTime() >= data.respawnAt) respawn(level, data);
            return;
        }

        Entity e = data.entityId == null ? null : level.getEntity(data.entityId);
        if ((e == null || !e.isAlive()) && level.hasChunkAt(data.lastPos)) {
            // it vanished (e.g. /kill-less removal): bring it back from saved data
            data.dead = true;
            data.respawnAt = level.getGameTime();
            data.setDirty();
        }
    }

    public static void onAIDied(ServerLevel level, AIPlayerEntity ai) {
        AIPlayerData data = AIPlayerData.get(level.getServer());
        data.inventory = ai.saveInventory();
        data.dead = true;
        data.entityId = null;
        data.deaths++;
        data.respawnAt = level.getGameTime() + RESPAWN_DELAY_TICKS;
        releaseForced(level, data);
        data.setDirty();
    }

    /** Valid bed -> back to the bed, otherwise back to the original spawn place. */
    private static void respawn(ServerLevel level, AIPlayerData data) {
        Vec3 pos;
        if (data.bed != null && level.getBlockState(data.bed).getBlock() instanceof BedBlock) {
            pos = new Vec3(data.bed.getX() + 0.5D, data.bed.getY() + 0.6D, data.bed.getZ() + 0.5D);
        } else {
            data.bed = null;
            pos = Vec3.atBottomCenterOf(data.origin);
        }
        spawn(level, data, pos);
    }

    private static void spawn(ServerLevel level, AIPlayerData data, Vec3 pos) {
        level.getChunkAt(BlockPos.containing(pos)); // make sure the chunk is loaded
        AIPlayerEntity ai = ModEntities.AI_PLAYER.get().create(level);
        if (ai == null) return;
        ai.moveTo(pos.x, pos.y, pos.z, level.random.nextFloat() * 360.0F, 0.0F);
        ai.loadInventory(data.inventory);
        level.addFreshEntity(ai);
        data.entityId = ai.getUUID();
        data.dead = false;
        data.lastPos = ai.blockPosition();
        data.setDirty();
        updateForced(level, data, ai.chunkPosition());
    }

    public static BlockPos findSpawnAround(ServerLevel level, BlockPos center, double dist) {
        RandomSource r = level.random;
        BlockPos fallback = null;
        for (int i = 0; i < 12; i++) {
            double a = r.nextDouble() * Math.PI * 2.0D;
            int x = center.getX() + (int) Math.round(Math.cos(a) * dist);
            int z = center.getZ() + (int) Math.round(Math.sin(a) * dist);
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos p = new BlockPos(x, y, z);
            if (fallback == null) fallback = p;
            if (level.getFluidState(p.below()).isEmpty() && level.getBlockState(p).isAir()) return p;
        }
        return fallback;
    }

    // ---- Keep the AI's surroundings loaded so it keeps acting when you are far
    public static void updateForced(ServerLevel level, AIPlayerData data, ChunkPos cp) {
        if (data.hasForced && data.forcedX == cp.x && data.forcedZ == cp.z) return;
        releaseForced(level, data);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                level.setChunkForced(cp.x + dx, cp.z + dz, true);
            }
        }
        data.hasForced = true;
        data.forcedX = cp.x;
        data.forcedZ = cp.z;
        data.setDirty();
    }

    public static void releaseForced(ServerLevel level, AIPlayerData data) {
        if (!data.hasForced) return;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                level.setChunkForced(data.forcedX + dx, data.forcedZ + dz, false);
            }
        }
        data.hasForced = false;
        data.setDirty();
    }

    // ---- W button: teleport the REAL player to the AI (never the reverse) ----
    public static void teleportPlayerToAI(ServerPlayer player) {
        MinecraftServer server = player.server;
        ServerLevel level = server.overworld();
        AIPlayerData data = AIPlayerData.get(server);

        Entity ai = (data.dead || data.entityId == null) ? null : level.getEntity(data.entityId);
        if (ai == null || !ai.isAlive()) {
            player.displayClientMessage(Component.translatable("message.reverse_horror.ai_missing"), true);
            return;
        }
        boolean sameLevel = player.level() == level;
        if (sameLevel && player.distanceToSqr(ai)
                <= TELEPORT_MIN_DISTANCE * TELEPORT_MIN_DISTANCE) {
            player.displayClientMessage(Component.translatable("message.reverse_horror.ai_too_close"), true);
            return;
        }

        // land ~3 blocks next to it (not on top of it, so you can't instantly "catch" it)
        Vec3 target = ai.position();
        for (int i = 0; i < 8; i++) {
            double ang = i * Math.PI / 4.0D;
            double dx = ai.getX() + Math.cos(ang) * 3.0D - player.getX();
            double dy = ai.getY() - player.getY();
            double dz = ai.getZ() + Math.sin(ang) * 3.0D - player.getZ();
            if (level.noCollision(player, player.getBoundingBox().move(dx, dy, dz))) {
                target = new Vec3(player.getX() + dx, player.getY() + dy, player.getZ() + dz);
                break;
            }
        }
        player.teleportTo(level, target.x, target.y, target.z, player.getYRot(), player.getXRot());
        player.resetFallDistance();
        player.displayClientMessage(Component.translatable("message.reverse_horror.teleported"), true);
    }

    // ---- Debug helpers used by /rh --------------------------------------------
    public static void summonNear(ServerPlayer player) {
        MinecraftServer server = player.server;
        ServerLevel level = server.overworld();
        if (player.level() != level) return;
        AIPlayerData data = AIPlayerData.get(server);
        Entity old = (data.dead || data.entityId == null) ? null : level.getEntity(data.entityId);
        if (old instanceof AIPlayerEntity oldAi && oldAi.isAlive()) {
            data.inventory = oldAi.saveInventory();
            oldAi.discard();
        }
        BlockPos pos = findSpawnAround(level, player.blockPosition(), SPAWN_DISTANCE);
        data.origin = pos;
        data.spawned = true;
        spawn(level, data, Vec3.atBottomCenterOf(pos));
    }

    public static String status(MinecraftServer server) {
        ServerLevel level = server.overworld();
        AIPlayerData d = AIPlayerData.get(server);
        Entity e = (d.dead || d.entityId == null) ? null : level.getEntity(d.entityId);
        String state = !d.spawned ? "not spawned yet" : d.dead ? "dead (respawning)"
                : (e != null && e.isAlive()) ? "alive at " + e.blockPosition().toShortString() : "not found";
        return "AI: " + state + " | deaths " + d.deaths + " | logs chopped " + d.logsChopped
                + " | bed " + (d.bed == null ? "none" : d.bed.toShortString())
                + " | origin " + d.origin.toShortString();
    }
}
