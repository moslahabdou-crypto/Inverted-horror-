package com.reversehorror;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.behavior.WalkTarget;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class CleaverEvents {
    private static final String GOT_CLEAVER = "rh_got_cleaver";
    private static final double SCARE_RADIUS = 14.0D;
    private static final int SCAN_INTERVAL_TICKS = 10;

    /** Give the clean cleaver once, the first time a player joins. */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) return;

        CompoundTag data = player.getPersistentData();
        CompoundTag persisted = data.getCompound(Player.PERSISTED_NBT_TAG);
        if (persisted.getBoolean(GOT_CLEAVER)) return;

        persisted.putBoolean(GOT_CLEAVER, true);
        data.put(Player.PERSISTED_NBT_TAG, persisted);

        ItemStack cleaver = new ItemStack(ModItems.CLEAVER.get());
        if (!player.getInventory().add(cleaver)) {
            player.drop(cleaver, false);
        }
    }

    /** Killing any living thing with the cleaver in the main hand makes it bloody. */
    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) return;

        if (event.getSource().getEntity() instanceof Player killer && killer != victim) {
            ItemStack held = killer.getMainHandItem();
            if (held.getItem() instanceof CleaverItem) {
                CleaverItem.setBloody(held, true);
            }
        }
    }

    /**
     * While a player holds a bloody cleaver (either hand), nearby animals and
     * villagers run away. Scans only every 10 ticks, only for such players.
     */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side.isClient()) return;

        Player player = event.player;
        if (player.tickCount % SCAN_INTERVAL_TICKS != 0 || player.isSpectator()) return;
        if (!CleaverItem.isBloody(player.getMainHandItem())
                && !CleaverItem.isBloody(player.getOffhandItem())) return;

        var box = player.getBoundingBox().inflate(SCARE_RADIUS);
        for (PathfinderMob mob : player.level().getEntitiesOfClass(PathfinderMob.class, box,
                m -> m instanceof Animal || m instanceof AbstractVillager)) {

            double distSqr = mob.distanceToSqr(player);
            if (distSqr > SCARE_RADIUS * SCARE_RADIUS) continue;
            // avoid re-pathing every scan unless it finished or the player is close
            if (!mob.getNavigation().isDone() && distSqr > 36.0D) continue;

            Vec3 away = DefaultRandomPos.getPosAway(mob, 16, 7, player.position());
            if (away == null) continue;

            if (mob instanceof Villager villager) {
                villager.getBrain().setMemory(MemoryModuleType.WALK_TARGET,
                        new WalkTarget(away, 0.8F, 1));
            }
            mob.getNavigation().moveTo(away.x, away.y, away.z, 1.3D);
        }
    }
}
