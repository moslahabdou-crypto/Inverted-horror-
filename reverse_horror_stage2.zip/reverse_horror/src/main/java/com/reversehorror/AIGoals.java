package com.reversehorror;

import java.util.EnumSet;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.phys.Vec3;

public class AIGoals {

    /** While chased: run away from the hunter. */
    public static class ChaseFleeGoal extends Goal {
        private final AIPlayerEntity mob;
        private int repath;

        public ChaseFleeGoal(AIPlayerEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            return mob.isChasing();
        }

        @Override
        public boolean canContinueToUse() {
            return mob.isChasing();
        }

        @Override
        public void start() {
            repath = 0;
        }

        @Override
        public void tick() {
            if (--repath > 0) return;
            repath = 8;
            Player hunter = mob.getHunter();
            Vec3 from = hunter != null ? hunter.position() : mob.position();
            Vec3 pos = DefaultRandomPos.getPosAway(mob, 24, 10, from);
            if (pos == null) pos = LandRandomPos.getPos(mob, 16, 7);
            if (pos != null) {
                mob.getNavigation().moveTo(pos.x, pos.y, pos.z, AIPlayerEntity.CHASE_SPEED);
            }
        }
    }

    /** At night: walk to a known / nearby bed and sleep in it. */
    public static class SleepGoal extends Goal {
        private final AIPlayerEntity mob;
        private BlockPos bed;
        private int cooldown;
        private int repath;

        public SleepGoal(AIPlayerEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        private static boolean isBedHead(Level level, BlockPos p) {
            BlockState s = level.getBlockState(p);
            return s.getBlock() instanceof BedBlock && s.getValue(BedBlock.PART) == BedPart.HEAD;
        }

        private BlockPos findBed() {
            Level level = mob.level();
            if (mob.level() instanceof net.minecraft.server.level.ServerLevel sl) {
                AIPlayerData d = AIPlayerData.get(sl.getServer());
                if (d.bed != null && isBedHead(level, d.bed)) return d.bed;
            }
            BlockPos o = mob.blockPosition();
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            for (BlockPos p : BlockPos.betweenClosed(o.offset(-16, -6, -16), o.offset(16, 6, 16))) {
                double dist = p.distSqr(o);
                if (dist >= bestD) continue;
                if (isBedHead(level, p)) {
                    best = p.immutable();
                    bestD = dist;
                }
            }
            return best;
        }

        @Override
        public boolean canUse() {
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            if (mob.isChasing() || mob.isSleeping() || !AIPlayerManager.isNight(mob.level())) return false;
            cooldown = 60;
            bed = findBed();
            return bed != null;
        }

        @Override
        public boolean canContinueToUse() {
            return bed != null && !mob.isChasing() && !mob.isSleeping()
                    && AIPlayerManager.isNight(mob.level())
                    && mob.level().getBlockState(bed).getBlock() instanceof BedBlock;
        }

        @Override
        public void start() {
            repath = 0;
        }

        @Override
        public void tick() {
            if (bed == null) return;
            if (mob.distanceToSqr(bed.getX() + 0.5D, bed.getY() + 0.5D, bed.getZ() + 0.5D) <= 4.0D) {
                mob.sleepAt(bed);
                bed = null;
                return;
            }
            if (--repath <= 0) {
                mob.getNavigation().moveTo(bed.getX() + 0.5D, bed.getY(), bed.getZ() + 0.5D, 1.0D);
                repath = 20;
            }
        }

        @Override
        public void stop() {
            bed = null;
        }
    }

    /** Find the nearest tree log, walk to it, chop it, put the log in its inventory. */
    public static class GatherWoodGoal extends Goal {
        private static final int RADIUS = 12;
        private static final int RADIUS_Y = 8;
        private final AIPlayerEntity mob;
        private BlockPos target;
        private int breakTicks;
        private int repath;
        private int stuck;
        private int cooldown;

        public GatherWoodGoal(AIPlayerEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        /** A log counts as a tree if leaves are around/above it (avoids chopping player houses). */
        private static boolean isTreeLog(Level level, BlockPos p) {
            for (int dy = 0; dy <= 6; dy++) {
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        if (level.getBlockState(p.offset(dx, dy, dz)).is(BlockTags.LEAVES)) return true;
                    }
                }
            }
            return false;
        }

        private BlockPos findLog() {
            Level level = mob.level();
            BlockPos o = mob.blockPosition();
            BlockPos best = null;
            double bestD = Double.MAX_VALUE;
            for (BlockPos p : BlockPos.betweenClosed(o.offset(-RADIUS, -RADIUS_Y, -RADIUS),
                    o.offset(RADIUS, RADIUS_Y, RADIUS))) {
                if (!level.getBlockState(p).is(BlockTags.LOGS)) continue;
                double d = p.distSqr(o);
                if (d >= bestD) continue;
                if (mob.isBadLog(p) || !isTreeLog(level, p)) continue;
                best = p.immutable();
                bestD = d;
            }
            return best;
        }

        @Override
        public boolean canUse() {
            if (mob.isChasing() || mob.isSleeping()) return false;
            if (cooldown > 0) {
                cooldown--;
                return false;
            }
            if (mob.countLogs() >= AIPlayerEntity.MAX_LOGS) {
                cooldown = 200;
                return false;
            }
            target = findLog();
            if (target == null) {
                cooldown = 100;
                return false;
            }
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return target != null && !mob.isChasing() && !mob.isSleeping()
                    && mob.level().getBlockState(target).is(BlockTags.LOGS);
        }

        @Override
        public void start() {
            breakTicks = 0;
            stuck = 0;
            repath = 0;
            mob.equipChoppingTool();
        }

        @Override
        public void tick() {
            if (target == null) return;
            double cx = target.getX() + 0.5D, cy = target.getY() + 0.5D, cz = target.getZ() + 0.5D;
            if (mob.distanceToSqr(cx, cy, cz) > 16.0D) {
                if (--repath <= 0) {
                    mob.getNavigation().moveTo(cx, target.getY(), cz, 1.0D);
                    repath = 20;
                }
                if (++stuck > 400) { // can't reach it, give up on this log
                    mob.markBadLog(target);
                    target = null;
                }
            } else {
                mob.getNavigation().stop();
                mob.getLookControl().setLookAt(cx, cy, cz);
                breakTicks++;
                if (breakTicks % 10 == 1) mob.swing(InteractionHand.MAIN_HAND);
                int needed = mob.hasAxe() ? 15 : 40;
                if (breakTicks >= needed) {
                    mob.chopLog(target);
                    target = null;
                }
            }
        }

        @Override
        public void stop() {
            target = null;
            mob.getNavigation().stop();
        }
    }
}
