package com.reversehorror;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client -> server: "W" pressed. Carries no data; the server decides everything. */
public class TeleportToAIPacket {
    public static void encode(TeleportToAIPacket msg, FriendlyByteBuf buf) {
    }

    public static TeleportToAIPacket decode(FriendlyByteBuf buf) {
        return new TeleportToAIPacket();
    }

    public static void handle(TeleportToAIPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) AIPlayerManager.teleportPlayerToAI(player);
        });
        ctx.get().setPacketHandled(true);
    }
}
