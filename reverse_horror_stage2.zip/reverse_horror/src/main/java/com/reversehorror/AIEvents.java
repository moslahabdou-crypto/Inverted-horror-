package com.reversehorror;

import com.mojang.brigadier.Command;

import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

public class AIEvents {
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server != null) AIPlayerManager.tick(server);
    }

    /** /rh status  and  /rh summon  (ops only, for testing). */
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("rh")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("status").executes(ctx -> {
                    String s = AIPlayerManager.status(ctx.getSource().getServer());
                    ctx.getSource().sendSuccess(() -> Component.literal(s), false);
                    return Command.SINGLE_SUCCESS;
                }))
                .then(Commands.literal("summon").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    AIPlayerManager.summonNear(p);
                    ctx.getSource().sendSuccess(() -> Component.literal("AI summoned near you"), false);
                    return Command.SINGLE_SUCCESS;
                })));
    }
}
