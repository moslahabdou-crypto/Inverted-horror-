package com.reversehorror;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.InteractionHand;

/**
 * The AI player. Autonomous state machine (goals): flee when hunted, sleep at
 * night in a bed, chop trees, craft wooden tools (virtual crafting), wander.
 * Its inventory is stored in NBT and in AIPlayerData so it survives death.
 */
public class AIPlayerEntity extends PathfinderMob {
    // ---- Tunable constants -------------------------------------------------
    public static final int CHASE_TICKS = 600;              // 30 s
    public static final double DETECT_RADIUS = 6.0D;        // real player gets this close -> chase
    public static final double CATCH_DISTANCE_SQR = 1.8D * 1.8D;
    public static final int AI_SPEED_AMPLIFIER = 1;         // Speed II on the AI while chased
    public static final int HUNTER_SLOW_AMPLIFIER = 1;      // Slowness II on the hunter
    public static final double CHASE_SPEED = 1.5D;          // navigation speed modifier
    public static final int MAX_LOGS = 64;                  // stop chopping at this many logs

    private final SimpleContainer inventory = new SimpleContainer(36);
    private final Set<BlockPos> badLogs = new HashSet<>();
    private int chaseTicks;
    private UUID hunterId;

    public AIPlayerEntity(EntityType<? extends AIPlayerEntity> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
        this.getNavigation().setCanFloat(true);
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            this.setDropChance(slot, 0.0F);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ATTACK_DAMAGE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AIGoals.ChaseFleeGoal(this));
        this.goalSelector.addGoal(2, new AIGoals.SleepGoal(this));
        this.goalSelector.addGoal(3, new OpenDoorGoal(this, true));
        this.goalSelector.addGoal(4, new AIGoals.GatherWoodGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    // ---- Chase -------------------------------------------------------------
    public boolean isChasing() {
        return chaseTicks > 0;
    }

    public Player getHunter() {
        return hunterId == null ? null : this.level().getPlayerByUUID(hunterId);
    }

    private void startChase(Player hunter) {
        chaseTicks = CHASE_TICKS;
        hunterId = hunter.getUUID();
        if (this.isSleeping()) this.stopSleeping();
        this.getNavigation().stop();
        this.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, CHASE_TICKS, 0, false, false));
        this.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, CHASE_TICKS,
                AI_SPEED_AMPLIFIER, false, false));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide || !(this.level() instanceof ServerLevel sl)) return;
        if (this.isDeadOrDying()) return;

        // start a chase when the real player comes close
        if (chaseTicks <= 0 && this.tickCount % 5 == 0) {
            Player p = this.level().getNearestPlayer(this, DETECT_RADIUS);
            if (p != null && !p.isSpectator()) startChase(p);
        }

        if (chaseTicks > 0) {
            chaseTicks--;
            Player hunter = getHunter();
            if (hunter != null) {
                if (this.tickCount % 10 == 0 && this.distanceToSqr(hunter) < 48.0D * 48.0D) {
                    hunter.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30,
                            HUNTER_SLOW_AMPLIFIER, false, false, true));
                }
                if (this.distanceToSqr(hunter) < CATCH_DISTANCE_SQR) {
                    // caught -> dies
                    this.hurt(this.damageSources().playerAttack(hunter), 1000.0F);
                    return;
                }
            }
        }

        // wake up at day
        if (this.isSleeping() && !AIPlayerManager.isNight(this.level())) {
            this.stopSleeping();
        }

        if (this.tickCount % 20 == 0) {
            syncData(sl);
        }
        if (this.tickCount % 40 == 0) {
            craftTools();
        }
    }

    @Override
    public boolean isImmobile() {
        return super.isImmobile() || this.isSleeping();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && this.isSleeping()) this.stopSleeping();
        return super.hurt(source, amount);
    }

    // ---- Death: keep inventory & progress, no drops ------------------------
    @Override
    public void die(DamageSource source) {
        if (!this.level().isClientSide && this.level() instanceof ServerLevel sl) {
            AIPlayerManager.onAIDied(sl, this);
        }
        super.die(source);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        // intentionally nothing: the AI keeps its inventory
    }

    @Override
    protected int getExperienceReward() {
        return 0;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    private void syncData(ServerLevel sl) {
        AIPlayerData d = AIPlayerData.get(sl.getServer());
        d.inventory = inventory.createTag();
        d.lastPos = this.blockPosition();
        d.entityId = this.getUUID();
        d.setDirty();
        AIPlayerManager.updateForced(sl, d, this.chunkPosition());
    }

    // ---- Inventory ---------------------------------------------------------
    public ListTag saveInventory() {
        return inventory.createTag();
    }

    public void loadInventory(ListTag tag) {
        inventory.fromTag(tag);
    }

    public SimpleContainer getInventory() {
        return inventory;
    }

    public int countLogs() {
        int n = 0;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(ItemTags.LOGS)) n += s.getCount();
        }
        return n;
    }

    private ItemStack findStack(Class<? extends Item> cls) {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty() && cls.isInstance(s.getItem())) return s;
        }
        return ItemStack.EMPTY;
    }

    public boolean hasAxe() {
        return !findStack(AxeItem.class).isEmpty();
    }

    public void equipChoppingTool() {
        ItemStack axe = findStack(AxeItem.class);
        this.setItemSlot(EquipmentSlot.MAINHAND, axe.isEmpty() ? ItemStack.EMPTY : axe.copy());
    }

    // ---- Virtual crafting (no crafting table needed) -----------------------
    private boolean logToPlanks() {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (s.is(ItemTags.LOGS)) {
                s.shrink(1);
                inventory.addItem(new ItemStack(Items.OAK_PLANKS, 4));
                return true;
            }
        }
        return false;
    }

    private boolean ensurePlanks(int n) {
        while (inventory.countItem(Items.OAK_PLANKS) < n) {
            if (!logToPlanks()) return false;
        }
        return true;
    }

    private boolean ensureSticks(int n) {
        while (inventory.countItem(Items.STICK) < n) {
            if (!ensurePlanks(2)) return false;
            inventory.removeItemType(Items.OAK_PLANKS, 2);
            inventory.addItem(new ItemStack(Items.STICK, 4));
        }
        return true;
    }

    private boolean makeTool(Item tool) {
        if (!ensureSticks(2) || !ensurePlanks(3)) return false;
        inventory.removeItemType(Items.STICK, 2);
        inventory.removeItemType(Items.OAK_PLANKS, 3);
        inventory.addItem(new ItemStack(tool));
        return true;
    }

    private void craftTools() {
        if (findStack(AxeItem.class).isEmpty()) makeTool(Items.WOODEN_AXE);
        if (findStack(PickaxeItem.class).isEmpty()) makeTool(Items.WOODEN_PICKAXE);
    }

    // ---- Chopping ----------------------------------------------------------
    public void chopLog(BlockPos pos) {
        BlockState st = this.level().getBlockState(pos);
        if (!st.is(BlockTags.LOGS)) return;
        Item drop = st.getBlock().asItem();
        this.level().destroyBlock(pos, false, this);
        ItemStack rest = inventory.addItem(new ItemStack(drop));
        if (!rest.isEmpty()) this.spawnAtLocation(rest);
        if (this.level() instanceof ServerLevel sl) {
            AIPlayerData d = AIPlayerData.get(sl.getServer());
            d.logsChopped++;
            d.setDirty();
        }
    }

    public boolean isBadLog(BlockPos p) {
        return badLogs.contains(p);
    }

    public void markBadLog(BlockPos p) {
        if (badLogs.size() > 200) badLogs.clear();
        badLogs.add(p.immutable());
    }

    // ---- Sleep -------------------------------------------------------------
    public void sleepAt(BlockPos bed) {
        this.startSleeping(bed);
        if (this.level() instanceof ServerLevel sl) {
            AIPlayerData d = AIPlayerData.get(sl.getServer());
            d.bed = bed.immutable();
            d.setDirty();
        }
    }

    // ---- NBT ---------------------------------------------------------------
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.put("AIInventory", inventory.createTag());
        tag.putInt("ChaseTicks", chaseTicks);
        if (hunterId != null) tag.putUUID("Hunter", hunterId);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("AIInventory", Tag.TAG_LIST)) {
            inventory.fromTag(tag.getList("AIInventory", Tag.TAG_COMPOUND));
        }
        chaseTicks = tag.getInt("ChaseTicks");
        if (tag.hasUUID("Hunter")) hunterId = tag.getUUID("Hunter");
    }
}
