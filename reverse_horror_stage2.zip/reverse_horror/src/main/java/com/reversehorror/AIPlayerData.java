package com.reversehorror;

import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** World-persistent state of the single AI player (survives its death). */
public class AIPlayerData extends SavedData {
    public static final String NAME = "reverse_horror_ai";

    public boolean spawned;
    public boolean dead;
    public long respawnAt;
    public UUID entityId;
    public BlockPos origin = BlockPos.ZERO;
    public BlockPos lastPos = BlockPos.ZERO;
    public BlockPos bed; // last bed it slept in (null = none)
    public ListTag inventory = new ListTag();
    public boolean hasForced;
    public int forcedX, forcedZ;
    public int deaths;
    public int logsChopped;

    public static AIPlayerData get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(AIPlayerData::load, AIPlayerData::new, NAME);
    }

    public static AIPlayerData load(CompoundTag t) {
        AIPlayerData d = new AIPlayerData();
        d.spawned = t.getBoolean("Spawned");
        d.dead = t.getBoolean("Dead");
        d.respawnAt = t.getLong("RespawnAt");
        if (t.hasUUID("EntityId")) d.entityId = t.getUUID("EntityId");
        d.origin = NbtUtils.readBlockPos(t.getCompound("Origin"));
        d.lastPos = NbtUtils.readBlockPos(t.getCompound("LastPos"));
        if (t.contains("Bed")) d.bed = NbtUtils.readBlockPos(t.getCompound("Bed"));
        d.inventory = t.getList("Inventory", Tag.TAG_COMPOUND);
        d.hasForced = t.getBoolean("HasForced");
        d.forcedX = t.getInt("ForcedX");
        d.forcedZ = t.getInt("ForcedZ");
        d.deaths = t.getInt("Deaths");
        d.logsChopped = t.getInt("LogsChopped");
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("Spawned", spawned);
        t.putBoolean("Dead", dead);
        t.putLong("RespawnAt", respawnAt);
        if (entityId != null) t.putUUID("EntityId", entityId);
        t.put("Origin", NbtUtils.writeBlockPos(origin));
        t.put("LastPos", NbtUtils.writeBlockPos(lastPos));
        if (bed != null) t.put("Bed", NbtUtils.writeBlockPos(bed));
        t.put("Inventory", inventory);
        t.putBoolean("HasForced", hasForced);
        t.putInt("ForcedX", forcedX);
        t.putInt("ForcedZ", forcedZ);
        t.putInt("Deaths", deaths);
        t.putInt("LogsChopped", logsChopped);
        return t;
    }
}
