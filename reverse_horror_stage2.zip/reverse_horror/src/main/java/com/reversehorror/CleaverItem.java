package com.reversehorror;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.ChatFormatting;

/** The cleaver. Its "bloody" state is stored in the item's NBT. */
public class CleaverItem extends SwordItem {
    public static final String TAG_BLOODY = "Bloody";

    public CleaverItem() {
        super(Tiers.IRON, 3, -2.4F, new Item.Properties().stacksTo(1));
    }

    public static boolean isBloody(ItemStack stack) {
        return stack.getItem() instanceof CleaverItem
                && stack.hasTag()
                && stack.getTag().getBoolean(TAG_BLOODY);
    }

    public static void setBloody(ItemStack stack, boolean bloody) {
        if (!(stack.getItem() instanceof CleaverItem)) return;
        if (bloody) {
            stack.getOrCreateTag().putBoolean(TAG_BLOODY, true);
        } else if (stack.hasTag()) {
            stack.getTag().remove(TAG_BLOODY);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level,
                                List<Component> tooltip, TooltipFlag flag) {
        if (isBloody(stack)) {
            tooltip.add(Component.translatable("tooltip.reverse_horror.bloody")
                    .withStyle(ChatFormatting.DARK_RED));
        }
    }
}
