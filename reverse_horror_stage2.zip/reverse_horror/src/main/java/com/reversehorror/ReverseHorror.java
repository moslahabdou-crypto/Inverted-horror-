package com.reversehorror;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ReverseHorror.MODID)
public class ReverseHorror {
    public static final String MODID = "reverse_horror";

    public ReverseHorror() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModNetwork.register();
        modBus.addListener(this::addToCreativeTab);
        MinecraftForge.EVENT_BUS.register(new CleaverEvents());
        MinecraftForge.EVENT_BUS.register(new AIEvents());
    }

    private void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.CLEAVER);
        }
    }
}
