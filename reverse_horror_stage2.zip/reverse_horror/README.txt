Reverse Horror - Stage 2 (cleaver + AI player + K)  |  Forge 1.20.1 (47.x)  |  Java 17

BUILD (UNTESTED - written without Forge/network):
1. Download the official Forge 1.20.1 MDK (files.minecraftforge.net, version 47.x).
2. Copy gradlew, gradlew.bat and the gradle/ folder from the MDK into this folder.
3. Run:  ./gradlew build   (Windows: gradlew build)   -> build/libs/reverse_horror-0.1.0.jar
   Dev test: ./gradlew runClient
If forge_version=47.3.0 isn't found, put an existing 47.x version in gradle.properties.

TESTING
- The AI spawns ~12 blocks from the first player in the overworld.
- /rh status  : shows AI state, position, logs chopped, bed.   (op only)
- /rh summon  : respawn the AI 12 blocks from you (keeps its inventory). (op only)
- K: button at top-left of the inventory screen and pause menu, or press K (rebindable in Controls).
- Tuning: constants at the top of AIPlayerEntity.java (chase time, speeds, detect radius).
